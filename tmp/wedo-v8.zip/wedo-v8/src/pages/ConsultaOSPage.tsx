import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getStatusOS, consultarOS, ConsultaOSResult, ConsultaOSDoc, ConsultaOSItem } from '@/api/consultaOS';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Search, Loader2, CheckCircle2, AlertTriangle, ShoppingCart,
  ChevronDown, ChevronRight, RefreshCw, Download, ClipboardList,
  PackageCheck, Clock, Package,
} from 'lucide-react';
import { toast } from 'sonner';

// ── Helpers ────────────────────────────────────────────────────────────────

function fmt(d?: string) {
  if (!d) return '—';
  try { const [y, m, day] = d.split('-'); return `${day}/${m}/${y}`; } catch { return d; }
}

function exportCSV(result: ConsultaOSResult) {
  const header = [
    'Código OS', 'Cliente', 'Situação', 'Data',
    'Produto', 'Qtd Necessária', 'Estoque', 'Em Compra (PO)', 'Prazo PO', 'Pedido(s)', 'Status',
  ];
  const rows: string[][] = [];
  for (const doc of result.docs) {
    for (const item of doc.itens) {
      rows.push([
        doc.os.codigo,
        doc.os.nome_cliente,
        doc.os.nome_situacao,
        doc.os.data,
        item.nome_produto,
        String(item.qtd_necessaria),
        String(item.estoque_atual),
        String(item.qtd_em_compra),
        item.prazo_po ?? '',
        item.po_codigo ?? '',
        item.status === 'ok' ? 'OK' : item.status === 'parcial' ? 'Coberto PO' : 'Faltando',
      ]);
    }
  }
  const csv = [header, ...rows]
    .map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';'))
    .join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `consulta-os-${result.scannedAt.slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ── OSCard ─────────────────────────────────────────────────────────────────

function OSCard({ doc }: { doc: ConsultaOSDoc }) {
  const [expanded, setExpanded] = useState(false);

  const borderColor =
    doc.itens_falta > 0 && doc.itens_ok === 0
      ? 'border-l-red-500'
      : doc.itens_falta > 0
      ? 'border-l-amber-500'
      : doc.itens_parcial > 0
      ? 'border-l-blue-500'
      : 'border-l-green-500';

  const overallIcon =
    doc.itens_falta === 0 && doc.itens_parcial === 0
      ? <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
      : doc.itens_parcial > 0 && doc.itens_falta === 0
      ? <ShoppingCart className="h-4 w-4 text-blue-500 shrink-0" />
      : <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0" />;

  return (
    <Card className={`border-l-4 ${borderColor}`}>
      {/* Header — clickable */}
      <div
        className="p-3 cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            {overallIcon}
            {/* Código da OS — first, prominent */}
            <span className="font-bold text-sm tabular-nums shrink-0">#{doc.os.codigo}</span>
            {/* Status pills */}
            <div className="flex items-center gap-1 shrink-0">
              {doc.itens_ok > 0 && (
                <Badge className="bg-green-600 text-white text-[10px] px-1.5 py-0">
                  {doc.itens_ok}✓
                </Badge>
              )}
              {doc.itens_parcial > 0 && (
                <Badge className="bg-blue-600 text-white text-[10px] px-1.5 py-0">
                  {doc.itens_parcial}PO
                </Badge>
              )}
              {doc.itens_falta > 0 && (
                <Badge className="bg-red-600 text-white text-[10px] px-1.5 py-0">
                  {doc.itens_falta}✗
                </Badge>
              )}
            </div>
            <span className="text-xs text-muted-foreground truncate">{doc.os.nome_cliente}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Badge variant="outline" className="text-[10px] px-1.5 hidden sm:flex">
              {doc.os.nome_situacao}
            </Badge>
            <span className="text-xs text-muted-foreground">{fmt(doc.os.data)}</span>
            {expanded
              ? <ChevronDown className="h-4 w-4 text-muted-foreground" />
              : <ChevronRight className="h-4 w-4 text-muted-foreground" />
            }
          </div>
        </div>

        {/* Situação on mobile */}
        <p className="text-xs text-muted-foreground mt-0.5 sm:hidden">{doc.os.nome_situacao}</p>
      </div>

      {/* Expanded item table */}
      {expanded && (
        <div className="border-t border-border px-3 pb-3 pt-2">
          {doc.itens.length === 0 ? (
            <p className="text-xs text-muted-foreground py-2">Nenhum produto listado nesta OS.</p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground border-b border-border">
                  <th className="text-left py-1.5 pr-2 font-medium">Produto</th>
                  <th className="text-right py-1 px-1 font-medium">Precisa</th>
                  <th className="text-right py-1 px-1 font-medium">Estoque</th>
                  <th className="text-right py-1 px-1 font-medium">Em Compra</th>
                  <th className="text-left py-1 pl-2 font-medium">Prazo PO</th>
                  <th className="text-center py-1 pl-1 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {doc.itens.map((item, idx) => (
                  <tr key={idx} className="border-b border-border/40 hover:bg-muted/30">
                    <td className="py-1.5 pr-2 max-w-[200px]">
                      <span className="truncate block" title={item.nome_produto}>
                        {item.nome_produto}
                      </span>
                      {item.codigo_produto && (
                        <span className="text-muted-foreground text-[10px]">{item.codigo_produto}</span>
                      )}
                    </td>
                    <td className="text-right py-1 px-1 tabular-nums">{item.qtd_necessaria}</td>
                    <td className={`text-right py-1 px-1 tabular-nums font-semibold ${
                      item.status === 'ok'
                        ? 'text-green-600'
                        : item.estoque_atual > 0
                        ? 'text-amber-600'
                        : 'text-red-500'
                    }`}>
                      {item.estoque_atual}
                    </td>
                    <td className={`text-right py-1 px-1 tabular-nums ${
                      item.qtd_em_compra > 0 ? 'text-blue-600 font-semibold' : 'text-muted-foreground'
                    }`}>
                      {item.qtd_em_compra > 0 ? item.qtd_em_compra : '—'}
                    </td>
                    <td className="py-1 pl-2 text-muted-foreground">
                      {item.prazo_po ? (
                        <span
                          title={`Pedido(s): ${item.po_codigo}`}
                          className="text-blue-600 font-medium cursor-help"
                        >
                          {fmt(item.prazo_po)}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="text-center py-1 pl-1">
                      {item.status === 'ok'
                        ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 inline" />
                        : item.status === 'parcial'
                        ? <ShoppingCart className="h-3.5 w-3.5 text-blue-500 inline" title="Coberto por PO" />
                        : <AlertTriangle className="h-3.5 w-3.5 text-red-500 inline" />
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </Card>
  );
}

// ── Page ───────────────────────────────────────────────────────────────────

export default function ConsultaOSPage() {
  const [nomeCliente, setNomeCliente] = useState('');
  const [selectedSituacoes, setSelectedSituacoes] = useState<string[]>([]);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState({ step: '', checked: 0, total: 0 });
  const [result, setResult] = useState<ConsultaOSResult | null>(null);

  const statusQuery = useQuery({
    queryKey: ['status-os'],
    queryFn: getStatusOS,
  });

  const toggleSituacao = (id: string) =>
    setSelectedSituacoes(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );

  const canSearch = selectedSituacoes.length > 0 || nomeCliente.trim().length > 0;

  const handleSearch = async () => {
    if (!canSearch) return;
    setScanning(true);
    setResult(null);
    setProgress({ step: 'Iniciando…', checked: 0, total: 0 });
    try {
      const res = await consultarOS(
        selectedSituacoes,
        nomeCliente.trim(),
        (step, checked, total) => setProgress({ step, checked, total }),
      );
      setResult(res);
      if (res.total === 0) toast.info('Nenhuma OS encontrada para os filtros informados.');
      else toast.success(`${res.total} OS encontrada(s).`);
    } catch (err) {
      toast.error('Erro ao consultar OS');
      console.error(err);
    } finally {
      setScanning(false);
    }
  };

  // Summary counts
  const totalOK = result?.docs.filter(d => d.itens_falta === 0 && d.itens_parcial === 0).length ?? 0;
  const totalPO = result?.docs.filter(d => d.itens_falta === 0 && d.itens_parcial > 0).length ?? 0;
  const totalFalta = result?.docs.filter(d => d.itens_falta > 0).length ?? 0;

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)] bg-background">

      {/* ── Controls ── */}
      <div className="bg-card border-b border-border p-4 space-y-3">
        <div className="flex items-center gap-2">
          <ClipboardList className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold text-foreground">Consulta de OS</h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Filtre por cliente e/ou situação para consultar o estoque das peças de cada OS.
        </p>

        {/* Client name input */}
        <div className="flex gap-2">
          <Input
            placeholder="Nome do cliente (opcional)"
            value={nomeCliente}
            onChange={e => setNomeCliente(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            disabled={scanning}
            className="flex-1 max-w-xs"
          />
        </div>

        {/* Situation checkboxes */}
        {statusQuery.isLoading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Carregando situações…
          </div>
        ) : (
          <div className="flex flex-wrap gap-3">
            {(statusQuery.data || []).map(s => (
              <label key={s.id} className="flex items-center gap-1.5 text-sm cursor-pointer">
                <Checkbox
                  checked={selectedSituacoes.includes(s.id)}
                  onCheckedChange={() => toggleSituacao(s.id)}
                  disabled={scanning}
                />
                {s.nome}
              </label>
            ))}
          </div>
        )}

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <Button
            onClick={handleSearch}
            disabled={!canSearch || scanning}
            className="gap-2"
          >
            {scanning
              ? <Loader2 className="h-4 w-4 animate-spin" />
              : <Search className="h-4 w-4" />
            }
            Consultar OS
          </Button>
          {result && (
            <>
              <Button variant="outline" size="sm" onClick={handleSearch} disabled={scanning} className="gap-1.5">
                <RefreshCw className="h-3.5 w-3.5" />
                Atualizar
              </Button>
              <Button variant="outline" size="sm" onClick={() => exportCSV(result)} className="gap-1.5">
                <Download className="h-3.5 w-3.5" />
                CSV
              </Button>
            </>
          )}
        </div>

        {/* Progress bar */}
        {scanning && (
          <div className="space-y-1">
            <Progress
              value={progress.total > 0 ? (progress.checked / progress.total) * 100 : 0}
              className="h-2"
            />
            <p className="text-xs text-muted-foreground text-center">
              {progress.step} {progress.total > 0 ? `${progress.checked}/${progress.total}` : ''}
            </p>
          </div>
        )}
      </div>

      {/* ── Results ── */}
      <div className="flex-1 overflow-y-auto p-4">

        {/* Empty state */}
        {!result && !scanning && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
            <ClipboardList className="h-10 w-10 opacity-30" />
            <p className="text-sm">Preencha ao menos um filtro e clique em "Consultar OS"</p>
          </div>
        )}

        {result && (
          <div className="space-y-5 max-w-3xl mx-auto">

            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Card className="p-3 text-center">
                <p className="text-2xl font-bold">{result.total}</p>
                <p className="text-xs text-muted-foreground">OS encontradas</p>
              </Card>
              <Card className="p-3 text-center border-green-500/40 bg-green-500/5">
                <p className="text-2xl font-bold text-green-600">{totalOK}</p>
                <p className="text-xs text-muted-foreground">Peças OK</p>
              </Card>
              <Card className="p-3 text-center border-blue-500/40 bg-blue-500/5">
                <p className="text-2xl font-bold text-blue-600">{totalPO}</p>
                <p className="text-xs text-muted-foreground">Cobertas por PO</p>
              </Card>
              <Card className="p-3 text-center border-red-500/40 bg-red-500/5">
                <p className="text-2xl font-bold text-red-500">{totalFalta}</p>
                <p className="text-xs text-muted-foreground">Com peças faltando</p>
              </Card>
            </div>

            <p className="text-xs text-muted-foreground text-right">
              Consultado em {new Date(result.scannedAt).toLocaleString('pt-BR')}
            </p>

            {/* Legend */}
            <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> OK (estoque suficiente)
              </span>
              <span className="flex items-center gap-1">
                <ShoppingCart className="h-3.5 w-3.5 text-blue-500" /> Coberto por PO
              </span>
              <span className="flex items-center gap-1">
                <AlertTriangle className="h-3.5 w-3.5 text-red-500" /> Faltando
              </span>
            </div>

            <Separator />

            {/* OS list */}
            {result.docs.length === 0 ? (
              <div className="flex flex-col items-center py-12 text-muted-foreground gap-2">
                <Package className="h-8 w-8 opacity-30" />
                <p className="text-sm">Nenhuma OS encontrada para os filtros informados.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {result.docs.map(doc => (
                  <OSCard key={doc.os.id} doc={doc} />
                ))}
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
}
