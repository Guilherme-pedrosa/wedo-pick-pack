import { PickingItem } from '@/api/types';
import { useCheckoutStore } from '@/store/checkoutStore';
import { CheckCircle2, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';

interface Props {
  items: PickingItem[];
}

export default function ItemsTable({ items }: Props) {
  const confirmItem = useCheckoutStore(s => s.confirmItem);
  const isMobile = useIsMobile();

  const fmtQtd = (n: number) => n % 1 === 0 ? String(n) : n.toFixed(3).replace('.', ',');

  const pending = items.filter(i => !i.conferido).sort((a, b) => a.nome_produto.localeCompare(b.nome_produto));
  const confirmed = items.filter(i => i.conferido);
  const sorted = [...pending, ...confirmed];

  const formatTime = (iso?: string) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  if (isMobile) {
    return (
      <div className="space-y-2">
        {sorted.map(item => (
          <div
            key={item.id}
            className={`rounded-lg border p-3 transition-colors ${
              item.conferido
                ? 'bg-green-50 border-green-200'
                : 'border-l-4 border-l-amber-400 border-border'
            }`}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  {item.conferido ? (
                    <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />
                  ) : (
                    <Package className="h-4 w-4 text-muted-foreground shrink-0" />
                  )}
                  <span className={`text-sm font-medium truncate ${item.conferido ? 'text-green-800' : ''}`}>
                    {item.nome_produto}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground ml-5.5">
                  {item.codigo_produto && (
                    <span className="font-mono">Cód: {item.codigo_produto}</span>
                  )}
                  {item.codigo_barras && (
                    <span className="font-mono">EAN: {item.codigo_barras}</span>
                  )}
                  <span>{item.sigla_unidade}</span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-sm font-bold">
                  {item.conferido
                    ? `${fmtQtd(item.qtd_total)}/${fmtQtd(item.qtd_total)}`
                    : `${fmtQtd(item.qtd_conferida)}/${fmtQtd(item.qtd_total)}`}
                </div>
                {item.conferido && (
                  <span className="text-green-600 text-xs">{formatTime(item.confirmed_at)}</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border text-left text-xs text-muted-foreground uppercase tracking-wider">
            <th className="py-2 px-3">Produto</th>
            <th className="py-2 px-3">Código</th>
            <th className="py-2 px-3">Cód. Barras</th>
            <th className="py-2 px-3 text-center">Conferidos</th>
            <th className="py-2 px-3 text-center">Total</th>
            <th className="py-2 px-3 text-center">Unid</th>
            <th className="py-2 px-3 text-center">Ação</th>
          </tr>
        </thead>
        <tbody>
          {sorted.map(item => (
            <tr
              key={item.id}
              className={`border-b border-border transition-colors ${
                item.conferido
                  ? 'bg-green-50'
                  : 'border-l-4 border-l-amber-400'
              }`}
            >
              <td className="py-2.5 px-3">
                <div className="flex items-center gap-2">
                  {item.conferido && <CheckCircle2 className="h-4 w-4 text-green-600 shrink-0" />}
                  <span className={item.conferido ? 'text-green-800' : 'font-medium'}>{item.nome_produto}</span>
                </div>
              </td>
              <td className="py-2.5 px-3 font-mono text-xs text-muted-foreground">
                {item.codigo_produto || '—'}
              </td>
              <td className="py-2.5 px-3 font-mono text-xs text-muted-foreground">
                {item.codigo_barras || '—'}
              </td>
              <td className="py-2.5 px-3 text-center font-medium">
                {item.conferido
                  ? `${fmtQtd(item.qtd_total)}/${fmtQtd(item.qtd_total)}`
                  : `${fmtQtd(item.qtd_conferida)}/${fmtQtd(item.qtd_total)}`}
              </td>
              <td className="py-2.5 px-3 text-center">{fmtQtd(item.qtd_total)}</td>
              <td className="py-2.5 px-3 text-center text-muted-foreground">{item.sigla_unidade}</td>
              <td className="py-2.5 px-3 text-center">
                {item.conferido && (
                  <span className="text-green-600 text-xs">{formatTime(item.confirmed_at)}</span>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
