import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ChevronDown,
  ChevronRight,
  CheckCircle,
  AlertTriangle,
  XCircle,
} from 'lucide-react';
import { TriagemOrcamento } from '@/api/types';

interface Props {
  orc: TriagemOrcamento;
}

const STATUS_CONFIG = {
  pronto: {
    label: '✅ Pronto para OS',
    color: 'bg-green-100 text-green-800 border-green-300',
    icon: CheckCircle,
    iconColor: 'text-green-600',
    rowBg: '',
  },
  parcial: {
    label: '⚠️ Parcial',
    color: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    icon: AlertTriangle,
    iconColor: 'text-yellow-600',
    rowBg: '',
  },
  aguardando: {
    label: '❌ Aguardando peças',
    color: 'bg-red-100 text-red-800 border-red-300',
    icon: XCircle,
    iconColor: 'text-red-600',
    rowBg: '',
  },
};

export default function OrcamentoCard({ orc }: Props) {
  const [expanded, setExpanded] = useState(false);
  const cfg = STATUS_CONFIG[orc.status];
  const Icon = cfg.icon;

  const formatCurrency = (v: number) =>
    v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

  return (
    <Collapsible open={expanded} onOpenChange={setExpanded}>
      <div className="border rounded-lg overflow-hidden bg-white shadow-sm">

        {/* Header row — clicável */}
        <CollapsibleTrigger asChild>
          <div className="flex items-center gap-3 p-3 cursor-pointer hover:bg-gray-50 transition-colors select-none">
            <Icon className={`h-4 w-4 shrink-0 ${cfg.iconColor}`} />

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm text-gray-900">{orc.codigo}</span>
                <Badge className={`text-xs border ${cfg.color} hover:${cfg.color}`}>
                  {cfg.label}
                </Badge>
              </div>
              <p className="text-xs text-gray-500 truncate mt-0.5">{orc.nome_cliente}</p>
            </div>

            <div className="text-right shrink-0 hidden sm:block">
              <p className="text-sm font-medium text-gray-900">{formatCurrency(orc.valor_total)}</p>
              <p className="text-xs text-gray-400">{orc.data}</p>
            </div>

            <div className="flex items-center gap-1.5 shrink-0 text-xs">
              {orc.itens_ok > 0 && (
                <span className="text-green-700 font-medium">{orc.itens_ok}✓</span>
              )}
              {orc.itens_faltando > 0 && (
                <span className="text-red-600 font-medium">{orc.itens_faltando}✗</span>
              )}
              {expanded ? (
                <ChevronDown className="h-4 w-4 text-gray-400" />
              ) : (
                <ChevronRight className="h-4 w-4 text-gray-400" />
              )}
            </div>
          </div>
        </CollapsibleTrigger>

        {/* Expanded — tabela de itens */}
        <CollapsibleContent>
          <div className="border-t">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="text-xs py-2">Produto</TableHead>
                  <TableHead className="text-xs py-2 text-center w-16">UN</TableHead>
                  <TableHead className="text-xs py-2 text-right w-24">Necessário</TableHead>
                  <TableHead className="text-xs py-2 text-right w-24">Estoque</TableHead>
                  <TableHead className="text-xs py-2 text-center w-28">Situação</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {orc.itens.map((item, idx) => (
                  <TableRow key={idx} className={item.estoque_suficiente ? '' : 'bg-red-50/60'}>
                    <TableCell className="py-2">
                      <p className="text-xs font-medium text-gray-900">{item.nome_produto}</p>
                      {item.codigo_produto && (
                        <p className="text-xs text-gray-400">{item.codigo_produto}</p>
                      )}
                    </TableCell>
                    <TableCell className="text-xs text-center py-2 text-gray-600">
                      {item.sigla_unidade || '—'}
                    </TableCell>
                    <TableCell className="text-xs text-right py-2 font-medium">
                      {item.quantidade_necessaria}
                    </TableCell>
                    <TableCell
                      className={`text-xs text-right py-2 font-bold ${
                        item.estoque_suficiente ? 'text-green-700' : 'text-red-600'
                      }`}
                    >
                      {item.estoque_atual}
                    </TableCell>
                    <TableCell className="text-xs text-center py-2">
                      {item.estoque_suficiente ? (
                        <span className="inline-flex items-center gap-1 text-green-700">
                          <CheckCircle className="h-3.5 w-3.5" /> OK
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-red-600">
                          <XCircle className="h-3.5 w-3.5" />
                          Falta {item.quantidade_necessaria - item.estoque_atual}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>

            {/* Footer simples — sem botão */}
            <div className="px-3 py-2 bg-gray-50 border-t text-xs text-gray-500">
              {orc.itens_ok} de {orc.itens.length} {orc.itens.length === 1 ? 'item' : 'itens'} com estoque suficiente
            </div>
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}
