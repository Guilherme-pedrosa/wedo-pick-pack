import { GCOrcamento, GCProdutoDetalhe, GCOrdemCompra, OrcamentoConvertidoWarning } from './types';
import {
  getStatusOrcamentos,
  listOrcamentos,
  getProdutoDetalhe,
  getStatusCompras,
  listOrdensCompra,
} from './compras';

export interface OrcamentoReadiness {
  orcamento: GCOrcamento;
  itens: Array<{
    produto_id: string;
    variacao_id: string;
    nome_produto: string;
    codigo_produto: string;
    qtd_necessaria: number;
    estoque_total: number;       // real stock in GC
    estoque_disponivel: number;  // remaining after prior allocations
    qtd_em_compra: number;       // qty covered by open POs
    prazo_po?: string;           // earliest delivery date from POs covering this item
    po_codigo?: string;          // PO code(s) covering this item
    pronto: boolean;             // stock alone covers need
    coberto_po: boolean;         // stock + PO covers need
  }>;
  totalItens: number;
  itensProntos: number;
  itensCobertospo: number;
  pronto: boolean;
  convertido: boolean;          // situacao_financeiro=1 && situacao_estoque=1
}

export interface ConflictInfo {
  produto_key: string;
  nome_produto: string;
  estoque_total: number;
  demanda_total: number;
  orcamentos_envolvidos: Array<{ id: string; codigo: string; nome_cliente: string; qtd: number }>;
}

export interface RastreadorResult {
  orcamentosProntos: OrcamentoReadiness[];
  orcamentosPendentes: OrcamentoReadiness[];
  conflitos: ConflictInfo[];
  orcamentosConvertidos: OrcamentoConvertidoWarning[];
  totalOrcamentos: number;
  totalProntos: number;
  totalConvertidos: number;
  scannedAt: string;
}

function normalizeId(value: string | number | null | undefined): string {
  if (value == null) return '';
  const raw = String(value).trim();
  if (!raw || raw === '0' || raw.toLowerCase() === 'null') return '';
  return raw;
}

function parseDecimal(value: string | number | null | undefined): number {
  if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
  if (value == null) return 0;
  const raw = String(value).trim();
  if (!raw) return 0;
  if (raw.includes(',') && raw.includes('.')) return parseFloat(raw.replace(/\./g, '').replace(',', '.')) || 0;
  if (raw.includes(',')) return parseFloat(raw.replace(',', '.')) || 0;
  return parseFloat(raw) || 0;
}

export { getStatusOrcamentos };

export async function rastrearOrcamentos(
  situacaoIds: string[],
  onProgress?: (step: string, checked: number, total: number) => void,
): Promise<RastreadorResult> {

  // Phase 1: Fetch budgets
  onProgress?.('Buscando orçamentos…', 0, 1);
  const allOrcamentos: GCOrcamento[] = [];
  const situacaoSet = new Set(situacaoIds);

  for (const sid of situacaoIds) {
    let page = 1;
    while (true) {
      const res = await listOrcamentos(sid, page);
      const filtered = res.data.filter(o => situacaoSet.has(String(o.situacao_id)));
      allOrcamentos.push(...filtered);
      if (page >= res.meta.total_paginas) break;
      page++;
      await new Promise(r => setTimeout(r, 400));
    }
  }

  // Deduplicate
  const uniqueOrcamentos = [...new Map(allOrcamentos.map(o => [o.id, o])).values()];

  // Phase 1b: Detect converted budgets
  const orcamentosConvertidos: OrcamentoConvertidoWarning[] = uniqueOrcamentos
    .filter(o => o.situacao_financeiro === '1' && o.situacao_estoque === '1')
    .map(o => ({
      orcamento_id: o.id,
      codigo: o.codigo,
      nome_cliente: o.nome_cliente,
      situacao_financeiro: o.situacao_financeiro!,
      situacao_estoque: o.situacao_estoque!,
    }));

  // Phase 2: Collect unique product IDs
  const uniqueProductIds = new Set<string>();
  for (const orc of uniqueOrcamentos) {
    for (const p of orc.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      if (pid) uniqueProductIds.add(pid);
    }
  }

  // Phase 3: Fetch stock for each product
  const productIds = [...uniqueProductIds];
  const detailCache = new Map<string, GCProdutoDetalhe | null>();
  const total = productIds.length;

  for (let i = 0; i < productIds.length; i += 2) {
    const batch = productIds.slice(i, i + 2);
    onProgress?.('Verificando estoque…', i, total);
    await Promise.all(batch.map(async pid => {
      if (!detailCache.has(pid)) {
        detailCache.set(pid, await getProdutoDetalhe(pid));
      }
    }));
    if (i + 2 < productIds.length) await new Promise(r => setTimeout(r, 500));
  }

  // Phase 3b: Fetch open purchase orders
  onProgress?.('Verificando pedidos de compra…', total, total);
  const allPOs: GCOrdemCompra[] = [];
  try {
    // Fetch all PO statuses, collect all "in progress" orders
    const poStatuses = await getStatusCompras();
    for (const st of poStatuses) {
      let page = 1;
      while (true) {
        const res = await listOrdensCompra(st.id, page);
        allPOs.push(...res.data);
        if (page >= res.meta.total_paginas) break;
        page++;
        await new Promise(r => setTimeout(r, 300));
      }
    }
  } catch (e) {
    console.warn('[RASTREADOR] Could not load POs:', e);
  }

  // Build PO coverage map: key -> { qtd_total, prazo, codigos[] }
  function makeKey(pid: string, vid: string) { return vid ? `${pid}::${vid}` : pid; }

  interface POCoverage {
    qtd: number;
    prazo?: string;
    codigos: string[];
  }
  const poCoverageMap = new Map<string, POCoverage>();

  for (const po of allPOs) {
    for (const p of po.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;
      const key = makeKey(pid, vid);
      const qtd = parseDecimal(p.produto.quantidade);
      const existing = poCoverageMap.get(key);
      if (!existing) {
        poCoverageMap.set(key, {
          qtd,
          prazo: po.prazo_entrega || undefined,
          codigos: [po.codigo],
        });
      } else {
        existing.qtd += qtd;
        existing.codigos.push(po.codigo);
        // Keep earliest delivery date
        if (po.prazo_entrega) {
          if (!existing.prazo || po.prazo_entrega < existing.prazo) {
            existing.prazo = po.prazo_entrega;
          }
        }
      }
    }
  }

  onProgress?.('Analisando resultados…', total, total);

  // Phase 4: Build real stock map (key -> stock quantity)
  const stockMap = new Map<string, number>();
  for (const orc of uniqueOrcamentos) {
    for (const p of orc.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;
      const key = makeKey(pid, vid);
      if (stockMap.has(key)) continue;

      const detail = detailCache.get(pid);
      let estoque = 0;
      if (detail) {
        if (vid && detail.variacoes?.length) {
          const v = detail.variacoes.find(v => String(v.variacao.id) === vid);
          estoque = v ? parseDecimal(v.variacao.estoque) : parseDecimal(detail.estoque);
        } else {
          estoque = parseDecimal(detail.estoque);
        }
      }
      stockMap.set(key, estoque);
    }
  }

  // Phase 5: Compute total demand per product across all budgets (conflict detection)
  const demandMap = new Map<string, { total: number; nome: string; orcamentos: Array<{ id: string; codigo: string; nome_cliente: string; qtd: number }> }>();
  for (const orc of uniqueOrcamentos) {
    for (const p of orc.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;
      const key = makeKey(pid, vid);
      const qtd = parseDecimal(p.produto.quantidade);
      if (!demandMap.has(key)) demandMap.set(key, { total: 0, nome: p.produto.nome_produto, orcamentos: [] });
      const entry = demandMap.get(key)!;
      entry.total += qtd;
      entry.orcamentos.push({ id: orc.id, codigo: orc.codigo, nome_cliente: orc.nome_cliente, qtd });
    }
  }

  // Detect conflicts: demand > stock AND multiple budgets need it
  const conflitos: ConflictInfo[] = [];
  for (const [key, demand] of demandMap) {
    const stock = stockMap.get(key) ?? 0;
    if (demand.total > stock && demand.orcamentos.length > 1) {
      conflitos.push({
        produto_key: key,
        nome_produto: demand.nome,
        estoque_total: stock,
        demanda_total: demand.total,
        orcamentos_envolvidos: demand.orcamentos,
      });
    }
  }

  // Phase 6: Smart allocation — prioritize budgets that can be 100% fulfilled
  const scoredOrcamentos = uniqueOrcamentos.map(orc => {
    let totalItems = 0;
    let itemsWithStock = 0;
    const itemsNeeded: Array<{ key: string; qtd: number }> = [];

    for (const p of orc.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;
      const key = makeKey(pid, vid);
      const qtd = parseDecimal(p.produto.quantidade);
      const stock = stockMap.get(key) ?? 0;
      totalItems++;
      if (stock >= qtd) itemsWithStock++;
      itemsNeeded.push({ key, qtd });
    }

    const readinessRatio = totalItems > 0 ? itemsWithStock / totalItems : 0;
    return { orc, readinessRatio, totalItems, itemsWithStock, itemsNeeded };
  });

  // Sort: highest readiness first, then by fewer total items
  scoredOrcamentos.sort((a, b) => {
    if (b.readinessRatio !== a.readinessRatio) return b.readinessRatio - a.readinessRatio;
    return a.totalItems - b.totalItems;
  });

  // Allocate stock cumulatively in priority order
  const remainingStock = new Map(stockMap);
  const prontos: OrcamentoReadiness[] = [];
  const pendentes: OrcamentoReadiness[] = [];
  const convertidoSet = new Set(orcamentosConvertidos.map(c => c.orcamento_id));

  for (const { orc, itemsNeeded } of scoredOrcamentos) {
    const itens: OrcamentoReadiness['itens'] = [];

    // Check if ALL items can be fulfilled with remaining stock
    let canFulfill = true;
    for (const { key, qtd } of itemsNeeded) {
      const available = remainingStock.get(key) ?? 0;
      if (available < qtd) canFulfill = false;
    }

    // Build item details
    for (const p of orc.produtos || []) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;
      const key = makeKey(pid, vid);
      const qtd = parseDecimal(p.produto.quantidade);
      const available = remainingStock.get(key) ?? 0;
      const stockTotal = stockMap.get(key) ?? 0;
      const poCov = poCoverageMap.get(key);
      const qtdEmCompra = poCov?.qtd ?? 0;
      const prontoPorEstoque = available >= qtd;
      const cobertoPO = !prontoPorEstoque && (available + qtdEmCompra) >= qtd;

      itens.push({
        produto_id: pid,
        variacao_id: vid,
        nome_produto: p.produto.nome_produto,
        codigo_produto: p.produto.codigo_produto,
        qtd_necessaria: qtd,
        estoque_total: stockTotal,
        estoque_disponivel: available,
        qtd_em_compra: qtdEmCompra,
        prazo_po: poCov?.prazo,
        po_codigo: poCov?.codigos.join(', '),
        pronto: prontoPorEstoque,
        coberto_po: cobertoPO,
      });
    }

    // If budget can be fully fulfilled, consume stock
    if (canFulfill && itens.length > 0) {
      for (const { key, qtd } of itemsNeeded) {
        remainingStock.set(key, (remainingStock.get(key) ?? 0) - qtd);
      }
    }

    const entry: OrcamentoReadiness = {
      orcamento: orc,
      itens,
      totalItens: itens.length,
      itensProntos: itens.filter(i => i.pronto).length,
      itensCobertospo: itens.filter(i => i.coberto_po).length,
      pronto: canFulfill && itens.length > 0,
      convertido: convertidoSet.has(orc.id),
    };

    if (entry.pronto) prontos.push(entry);
    else pendentes.push(entry);
  }

  return {
    orcamentosProntos: prontos,
    orcamentosPendentes: pendentes,
    conflitos,
    orcamentosConvertidos,
    totalOrcamentos: uniqueOrcamentos.length,
    totalProntos: prontos.length,
    totalConvertidos: orcamentosConvertidos.length,
    scannedAt: new Date().toISOString(),
  };
}
