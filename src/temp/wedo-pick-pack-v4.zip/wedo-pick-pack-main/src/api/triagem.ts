import { supabase } from '@/integrations/supabase/client';
import {
  GCSituacao,
  GCOrcamento,
  GCProdutoDetalhe,
  TriagemOrcamento,
  TriagemProdutoItem,
  TriagemResult,
} from './types';
import {
  MOCK_STATUS_ORCAMENTO,
  MOCK_ORCAMENTOS,
  MOCK_PRODUTOS_DETALHE,
} from './mockData';

// ─── helpers ────────────────────────────────────────────────────────────────

const isUsingMock = (): boolean => {
  try {
    const url = (supabase as any)?.supabaseUrl as string | undefined;
    return !url || url.includes('placeholder') || url.includes('localhost');
  } catch {
    return true;
  }
};

async function apiRequest<T>(path: string): Promise<T> {
  const { data, error } = await supabase.functions.invoke('gc-proxy', {
    body: { path, method: 'GET' },
  });
  if (error) throw new Error(error.message);
  return data as T;
}

function parseDecimal(value: string | number | undefined | null): number {
  if (value === null || value === undefined || value === '') return 0;
  const str = String(value).replace(/\./g, '').replace(',', '.');
  const n = parseFloat(str);
  return isNaN(n) ? 0 : n;
}

// ─── status de orçamento ────────────────────────────────────────────────────

export async function getStatusOrcamentosTriagem(): Promise<GCSituacao[]> {
  if (isUsingMock()) return MOCK_STATUS_ORCAMENTO;
  const res = await apiRequest<{ data: GCSituacao[] }>('/situacoes_orcamentos');
  return res.data ?? [];
}

// ─── varredura principal ─────────────────────────────────────────────────────

export async function varrerOrcamentosParaOS(
  situacaoId: string,
  onProgress?: (msg: string, pct: number) => void
): Promise<TriagemResult> {

  // Phase 1: buscar orçamentos com o status selecionado
  onProgress?.('Buscando orçamentos…', 5);

  let orcamentos: GCOrcamento[] = [];

  if (isUsingMock()) {
    orcamentos = MOCK_ORCAMENTOS.filter((o) => o.situacao_id === situacaoId);
    // fallback demo: se nenhum mock bate o status, usa todos
    if (orcamentos.length === 0) orcamentos = MOCK_ORCAMENTOS;
  } else {
    const res = await apiRequest<{ data: GCOrcamento[] }>(
      `/orcamentos?situacao_id=${situacaoId}&limite=200`
    );
    orcamentos = res.data ?? [];
  }

  onProgress?.(`${orcamentos.length} orçamento(s) encontrado(s)`, 15);

  // Phase 2: verificar estoque de cada produto (com cache para não repetir chamadas)
  const cache: Record<string, GCProdutoDetalhe> = {};
  const prontos: TriagemOrcamento[] = [];
  const parciais: TriagemOrcamento[] = [];
  const aguardando: TriagemOrcamento[] = [];

  for (let i = 0; i < orcamentos.length; i++) {
    const orc = orcamentos[i];
    const pct = 15 + Math.round(((i + 1) / orcamentos.length) * 80);
    onProgress?.(
      `Verificando ${orc.codigo} (${i + 1}/${orcamentos.length})`,
      pct
    );

    const itens: TriagemProdutoItem[] = [];

    for (const entry of orc.produtos ?? []) {
      const p = entry.produto;
      const pid = String(p.produto_id ?? '');
      if (!pid) continue;

      if (!cache[pid]) {
        if (isUsingMock()) {
          cache[pid] =
            MOCK_PRODUTOS_DETALHE[pid] ??
            ({
              id: pid,
              nome: p.nome_produto,
              codigo_interno: p.codigo_produto ?? '',
              codigo_barra: '',
              estoque: 0,
              valor_custo: '0',
              movimenta_estoque: '1',
              fornecedores: [],
            } as GCProdutoDetalhe);
        } else {
          try {
            cache[pid] = await apiRequest<GCProdutoDetalhe>(`/produtos/${pid}`);
          } catch {
            cache[pid] = {
              id: pid,
              nome: p.nome_produto,
              codigo_interno: p.codigo_produto ?? '',
              codigo_barra: '',
              estoque: 0,
              valor_custo: '0',
              movimenta_estoque: '1',
              fornecedores: [],
            } as GCProdutoDetalhe;
          }
        }
      }

      const detalhe = cache[pid];
      const estoqueAtual = parseDecimal(detalhe?.estoque);
      const qtdNecessaria = parseDecimal(p.quantidade);

      itens.push({
        produto_id: pid,
        variacao_id: String(p.variacao_id ?? ''),
        nome_produto: p.nome_produto ?? '—',
        codigo_produto: p.codigo_produto ?? detalhe?.codigo_interno ?? '',
        sigla_unidade: p.sigla_unidade ?? 'UND',
        quantidade_necessaria: qtdNecessaria,
        estoque_atual: estoqueAtual,
        estoque_suficiente: estoqueAtual >= qtdNecessaria,
      });
    }

    const itensOk = itens.filter((it) => it.estoque_suficiente).length;
    const itensFaltando = itens.length - itensOk;

    const triagem: TriagemOrcamento = {
      orcamento_id: String(orc.id),
      codigo: orc.codigo,
      cliente_id: String(orc.cliente_id ?? ''),
      nome_cliente: orc.nome_cliente ?? '—',
      valor_total: parseDecimal(orc.valor_total),
      data: orc.data ?? '',
      status:
        itensFaltando === 0 ? 'pronto' : itensOk > 0 ? 'parcial' : 'aguardando',
      itens,
      itens_ok: itensOk,
      itens_faltando: itensFaltando,
    };

    if (triagem.status === 'pronto') prontos.push(triagem);
    else if (triagem.status === 'parcial') parciais.push(triagem);
    else aguardando.push(triagem);
  }

  onProgress?.('Varredura concluída', 100);

  return {
    prontos,
    parciais,
    aguardando,
    total_orcamentos: orcamentos.length,
    scannedAt: new Date().toISOString(),
  };
}
