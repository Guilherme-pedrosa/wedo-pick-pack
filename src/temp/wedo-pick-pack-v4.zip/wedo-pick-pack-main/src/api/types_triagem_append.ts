
// --- TRIAGEM MODULE (append to types.ts) ---

export type TriagemStatus = 'pronto' | 'parcial' | 'aguardando';

export interface TriagemProdutoItem {
  produto_id: string;
  variacao_id: string;
  nome_produto: string;
  codigo_produto: string;
  sigla_unidade: string;
  quantidade_necessaria: number;
  estoque_atual: number;
  estoque_suficiente: boolean;
}

export interface TriagemOrcamento {
  orcamento_id: string;
  codigo: string;
  cliente_id: string;
  nome_cliente: string;
  valor_total: number;
  data: string;
  status: TriagemStatus;
  itens: TriagemProdutoItem[];
  itens_ok: number;
  itens_faltando: number;
}

export interface TriagemResult {
  prontos: TriagemOrcamento[];
  parciais: TriagemOrcamento[];
  aguardando: TriagemOrcamento[];
  total_orcamentos: number;
  scannedAt: string;
}
