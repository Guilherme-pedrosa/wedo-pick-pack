import { CheckCircle, AlertTriangle, XCircle, Clock, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTriagemStore } from '@/store/triagemStore';
import OrcamentoCard from './OrcamentoCard';

export default function TriagemResultPanel() {
  const { result, isScanning, setResult } = useTriagemStore();

  if (isScanning) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400 text-sm">
        Varrendo orçamentos…
      </div>
    );
  }

  if (!result) {
    return (
      <div className="flex flex-col items-center justify-center h-64 gap-3 text-gray-400">
        <Clock className="h-10 w-10" />
        <p className="text-sm">Nenhuma varredura realizada.</p>
        <p className="text-xs text-center max-w-xs">
          Selecione o status "Ag. Compra" no painel ao lado e clique em{' '}
          <strong>Varrer Orçamentos</strong>.
        </p>
      </div>
    );
  }

  const { prontos, parciais, aguardando, total_orcamentos, scannedAt } = result;

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

  return (
    <div className="space-y-6">
      {/* Summary cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <SummaryCard
          label="Total"
          value={total_orcamentos}
          color="gray"
          icon={<Clock className="h-5 w-5 text-gray-400" />}
        />
        <SummaryCard
          label="Prontos"
          value={prontos.length}
          color="green"
          icon={<CheckCircle className="h-5 w-5 text-green-500" />}
        />
        <SummaryCard
          label="Parciais"
          value={parciais.length}
          color="yellow"
          icon={<AlertTriangle className="h-5 w-5 text-yellow-500" />}
        />
        <SummaryCard
          label="Aguardando"
          value={aguardando.length}
          color="red"
          icon={<XCircle className="h-5 w-5 text-red-500" />}
        />
      </div>

      {/* Header meta */}
      <div className="flex items-center justify-between text-xs text-gray-400">
        <span>Varredura: {formatDate(scannedAt)}</span>
        <Button
          variant="ghost"
          size="sm"
          className="h-6 text-xs gap-1 text-gray-400 hover:text-gray-600"
          onClick={() => setResult(null)}
        >
          <RefreshCw className="h-3 w-3" />
          Limpar
        </Button>
      </div>

      {/* Prontos */}
      {prontos.length > 0 && (
        <Section
          title="✅ Prontos para OS"
          count={prontos.length}
          colorClass="text-green-700"
          borderClass="border-green-200"
          bgClass="bg-green-50"
        >
          {prontos.map((orc) => (
            <OrcamentoCard key={orc.orcamento_id} orc={orc} />
          ))}
        </Section>
      )}

      {/* Parciais */}
      {parciais.length > 0 && (
        <Section
          title="⚠️ Estoque parcial"
          count={parciais.length}
          colorClass="text-yellow-700"
          borderClass="border-yellow-200"
          bgClass="bg-yellow-50"
        >
          {parciais.map((orc) => (
            <OrcamentoCard key={orc.orcamento_id} orc={orc} />
          ))}
        </Section>
      )}

      {/* Aguardando */}
      {aguardando.length > 0 && (
        <Section
          title="❌ Aguardando peças"
          count={aguardando.length}
          colorClass="text-red-700"
          borderClass="border-red-200"
          bgClass="bg-red-50"
        >
          {aguardando.map((orc) => (
            <OrcamentoCard key={orc.orcamento_id} orc={orc} />
          ))}
        </Section>
      )}

      {total_orcamentos === 0 && (
        <div className="text-center py-10 text-gray-400 text-sm">
          Nenhum orçamento encontrado com o status selecionado.
        </div>
      )}
    </div>
  );
}

// ─── sub-components ──────────────────────────────────────────────────────────

function SummaryCard({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: number;
  color: 'gray' | 'green' | 'yellow' | 'red';
  icon: React.ReactNode;
}) {
  const bg = {
    gray: 'bg-gray-50 border-gray-200',
    green: 'bg-green-50 border-green-200',
    yellow: 'bg-yellow-50 border-yellow-200',
    red: 'bg-red-50 border-red-200',
  }[color];

  const text = {
    gray: 'text-gray-700',
    green: 'text-green-700',
    yellow: 'text-yellow-700',
    red: 'text-red-700',
  }[color];

  return (
    <div className={`rounded-lg border p-3 flex items-center gap-3 ${bg}`}>
      {icon}
      <div>
        <p className={`text-xl font-bold leading-none ${text}`}>{value}</p>
        <p className="text-xs text-gray-500 mt-0.5">{label}</p>
      </div>
    </div>
  );
}

function Section({
  title,
  count,
  colorClass,
  borderClass,
  bgClass,
  children,
}: {
  title: string;
  count: number;
  colorClass: string;
  borderClass: string;
  bgClass: string;
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <div className={`flex items-center justify-between px-3 py-2 rounded-md border ${bgClass} ${borderClass}`}>
        <h3 className={`text-sm font-semibold ${colorClass}`}>{title}</h3>
        <span className={`text-xs font-medium ${colorClass}`}>{count} orçamento(s)</span>
      </div>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
