import { GCOrdemServico, GCSituacao, GCProdutoDetalhe, GCOrdemCompra } from './types';
import {
  apiRequest,
  isUsingMock,
  getProdutoDetalhe,
  listOrdensCompra,
  getStatusCompras,
} from './compras';
import { MOCK_OS, MOCK_STATUS_OS } from './mockData';

// ── Types ──────────────────────────────────────────────────────────────────

export interface ConsultaOSItem {
  produto_id: string;
  variacao_id: string;
  nome_produto: string;
  codigo_produto: string;
  qtd_necessaria: number;
  estoque_atual: number;
  qtd_em_compra: number;
  prazo_po?: string;
  po_codigo?: string;
  status: 'ok' | 'parcial' | 'falta';
}

export interface ConsultaOSDoc {
  os: GCOrdemServico;
  itens: ConsultaOSItem[];
  total_itens: number;
  itens_ok: number;
  itens_parcial: number;
  itens_falta: number;
}

export interface ConsultaOSResult {
  docs: ConsultaOSDoc[];
  total: number;
  scannedAt: string;
}

// ── Helpers ────────────────────────────────────────────────────────────────

function normalizeId(v: string | number | null | undefined): string {
  if (v == null) return '';
  const s = String(v).trim();
  return s === '0' || s.toLowerCase() === 'null' ? '' : s;
}

function parseDecimal(v: string | number | null | undefined): number {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (v == null) return 0;
  const s = String(v).trim();
  if (!s) return 0;
  if (s.includes(',') && s.includes('.')) return parseFloat(s.replace(/\./g, '').replace(',', '.')) || 0;
  if (s.includes(',')) return parseFloat(s.replace(',', '.')) || 0;
  return parseFloat(s) || 0;
}

// ── Fetch OS statuses ──────────────────────────────────────────────────────

export async function getStatusOS(): Promise<GCSituacao[]> {
  if (isUsingMock()) return MOCK_STATUS_OS;
  try {
    const raw = await apiRequest<{ data: any[] }>('/api/situacoes_ordens_servicos');
    return (raw.data || []).map((r: any) => ({
      id: String(r?.id ?? ''),
      nome: String(r?.nome ?? ''),
    }));
  } catch {
    return MOCK_STATUS_OS;
  }
}

// ── Build PO coverage map ──────────────────────────────────────────────────

async function buildPOMap(): Promise<Map<string, { qtd: number; prazo?: string; codigos: string[] }>> {
  const map = new Map<string, { qtd: number; prazo?: string; codigos: string[] }>();
  try {
    const statuses = await getStatusCompras();
    for (const st of statuses) {
      const res = await listOrdensCompra(st.id);
      for (const po of res.data) {
        for (const p of po.produtos || []) {
          const pid = normalizeId(p.produto.produto_id);
          const vid = normalizeId(p.produto.variacao_id);
          if (!pid) continue;
          const key = vid ? `${pid}::${vid}` : pid;
          const qtd = parseDecimal(p.produto.quantidade);
          const ex = map.get(key);
          if (!ex) {
            map.set(key, { qtd, prazo: po.prazo_entrega || undefined, codigos: [po.codigo] });
          } else {
            ex.qtd += qtd;
            ex.codigos.push(po.codigo);
            if (po.prazo_entrega && (!ex.prazo || po.prazo_entrega < ex.prazo)) ex.prazo = po.prazo_entrega;
          }
        }
      }
    }
  } catch (e) {
    console.warn('[CONSULTA_OS] PO map failed:', e);
  }
  return map;
}

// ── Fetch OS list via API ──────────────────────────────────────────────────

async function fetchOS(situacaoId?: string, nomeCliente?: string): Promise<GCOrdemServico[]> {
  if (isUsingMock()) {
    let data = [...MOCK_OS];
    if (situacaoId) data = data.filter(o => o.situacao_id === situacaoId);
    if (nomeCliente) {
      const q = nomeCliente.toLowerCase();
      data = data.filter(o => o.nome_cliente.toLowerCase().includes(q));
    }
    return data;
  }

  const params: string[] = [];
  if (situacaoId) params.push(`situacao_id=${situacaoId}`);
  if (nomeCliente) params.push(`nome=${encodeURIComponent(nomeCliente)}`);

  const allOS: GCOrdemServico[] = [];
  let page = 1;

  while (true) {
    const qs = [...params, `pagina=${page}`].join('&');
    const raw = await apiRequest<{ data: any[]; meta: any }>(`/api/ordens_servicos?${qs}`);
    const rows = raw.data || [];

    for (const row of rows) {
      const os = row?.OrdemServico ?? row;
      allOS.push({
        id: String(os?.id ?? ''),
        codigo: String(os?.codigo ?? ''),
        cliente_id: String(os?.cliente_id ?? ''),
        nome_cliente: String(os?.nome_cliente ?? ''),
        data: String(os?.data ?? ''),
        situacao_id: String(os?.situacao_id ?? ''),
        nome_situacao: String(os?.nome_situacao ?? ''),
        valor_total: String(os?.valor_total ?? '0'),
        observacoes: os?.observacoes ?? undefined,
        produtos: (os?.produtos || []).map((p: any) => ({
          produto: {
            produto_id: String(p?.produto?.produto_id ?? ''),
            variacao_id: String(p?.produto?.variacao_id ?? ''),
            nome_produto: String(p?.produto?.nome_produto ?? ''),
            codigo_produto: String(p?.produto?.codigo_produto ?? ''),
            codigo_barras: String(p?.produto?.codigo_barras ?? ''),
            sigla_unidade: String(p?.produto?.sigla_unidade ?? ''),
            quantidade: p?.produto?.quantidade ?? 0,
          },
        })),
      });
    }

    const totalPages = raw.meta?.total_paginas ?? 1;
    if (page >= totalPages) break;
    page++;
    await new Promise(r => setTimeout(r, 400));
  }

  return allOS;
}

// ── Main function ──────────────────────────────────────────────────────────

export async function consultarOS(
  situacaoIds: string[],
  nomeCliente: string,
  onProgress?: (step: string, checked: number, total: number) => void,
): Promise<ConsultaOSResult> {
  onProgress?.('Buscando OS…', 0, 1);

  // Fetch OS — one request per situacao (or just by name if no situacao selected)
  const allOS: GCOrdemServico[] = [];
  const seen = new Set<string>();

  if (situacaoIds.length > 0) {
    for (const sid of situacaoIds) {
      const rows = await fetchOS(sid, nomeCliente || undefined);
      for (const os of rows) {
        if (!seen.has(os.id)) { seen.add(os.id); allOS.push(os); }
      }
    }
  } else if (nomeCliente) {
    const rows = await fetchOS(undefined, nomeCliente);
    for (const os of rows) {
      if (!seen.has(os.id)) { seen.add(os.id); allOS.push(os); }
    }
  }

  if (allOS.length === 0) {
    return { docs: [], total: 0, scannedAt: new Date().toISOString() };
  }

  // Collect unique product IDs
  const productIds = new Set<string>();
  for (const os of allOS) {
    for (const p of os.produtos) {
      const pid = normalizeId(p.produto.produto_id);
      if (pid) productIds.add(pid);
    }
  }

  // Fetch stock
  const detailCache = new Map<string, GCProdutoDetalhe | null>();
  const pids = [...productIds];
  const total = pids.length;

  for (let i = 0; i < pids.length; i += 2) {
    onProgress?.('Verificando estoque…', i, total);
    await Promise.all(pids.slice(i, i + 2).map(async pid => {
      if (!detailCache.has(pid)) detailCache.set(pid, await getProdutoDetalhe(pid));
    }));
    if (i + 2 < pids.length) await new Promise(r => setTimeout(r, 400));
  }

  // Fetch PO coverage
  onProgress?.('Verificando pedidos de compra…', total, total);
  const poMap = await buildPOMap();

  onProgress?.('Montando resultado…', total, total);

  // Build docs
  const docs: ConsultaOSDoc[] = allOS.map(os => {
    const itens: ConsultaOSItem[] = [];

    for (const p of os.produtos) {
      const pid = normalizeId(p.produto.produto_id);
      const vid = normalizeId(p.produto.variacao_id);
      if (!pid) continue;

      const detail = detailCache.get(pid);
      let estoque = 0;
      if (detail) {
        if (vid && detail.variacoes?.length) {
          const v = detail.variacoes.find(v => String(v.variacao.id) === vid);
          estoque = v ? parseDecimal(v.variacao.estoque) : parseDecimal(detail.estoque);
        } else {
          estoque = parseDecimal(detail.estoque);
        }
      }

      const key = vid ? `${pid}::${vid}` : pid;
      const poCov = poMap.get(key);
      const qtdNec = parseDecimal(p.produto.quantidade);
      const qtdEmCompra = poCov?.qtd ?? 0;

      let status: ConsultaOSItem['status'];
      if (estoque >= qtdNec) status = 'ok';
      else if (estoque + qtdEmCompra >= qtdNec) status = 'parcial';
      else status = 'falta';

      itens.push({
        produto_id: pid,
        variacao_id: vid,
        nome_produto: p.produto.nome_produto,
        codigo_produto: p.produto.codigo_produto,
        qtd_necessaria: qtdNec,
        estoque_atual: estoque,
        qtd_em_compra: qtdEmCompra,
        prazo_po: poCov?.prazo,
        po_codigo: poCov?.codigos.join(', '),
        status,
      });
    }

    return {
      os,
      itens,
      total_itens: itens.length,
      itens_ok: itens.filter(i => i.status === 'ok').length,
      itens_parcial: itens.filter(i => i.status === 'parcial').length,
      itens_falta: itens.filter(i => i.status === 'falta').length,
    };
  });

  return {
    docs,
    total: docs.length,
    scannedAt: new Date().toISOString(),
  };
}
