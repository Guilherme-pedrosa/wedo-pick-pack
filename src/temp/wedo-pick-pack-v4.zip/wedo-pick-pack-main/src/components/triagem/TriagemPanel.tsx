import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, ScanLine, AlertCircle, Info } from 'lucide-react';
import { getStatusOrcamentosTriagem, varrerOrcamentosParaOS } from '@/api/triagem';
import { useTriagemStore } from '@/store/triagemStore';
import { toast } from '@/components/ui/use-toast';

export default function TriagemPanel() {
  const { config, setConfig, isScanning, progress, progressPct, setIsScanning, setProgress, setResult } =
    useTriagemStore();

  const [localSituacao, setLocalSituacao] = useState(config.situacaoAgCompraId);

  const statusQuery = useQuery({
    queryKey: ['status-orcamentos-triagem'],
    queryFn: getStatusOrcamentosTriagem,
    staleTime: 5 * 60 * 1000,
  });

  const handleVarrer = async () => {
    if (!localSituacao) {
      toast({ title: 'Selecione o status "Ag. Compra"', variant: 'destructive' });
      return;
    }

    setConfig({ situacaoAgCompraId: localSituacao });
    setIsScanning(true);
    setResult(null);

    try {
      const result = await varrerOrcamentosParaOS(localSituacao, (msg, pct) => {
        setProgress(msg, pct ?? 0);
      });
      setResult(result);
      toast({
        title: 'Varredura concluída',
        description: `${result.prontos.length} prontos · ${result.parciais.length} parciais · ${result.aguardando.length} aguardando`,
      });
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Erro desconhecido';
      toast({ title: 'Erro na varredura', description: message, variant: 'destructive' });
    } finally {
      setIsScanning(false);
      setProgress('', 0);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2 className="text-base font-semibold text-gray-900">Triagem para OS</h2>
        <p className="text-xs text-gray-500 mt-0.5">
          Varredura de orçamentos aguardando peças × estoque atual
        </p>
      </div>

      {/* Status selector */}
      <div className="space-y-2">
        <label className="text-xs font-medium text-gray-700 uppercase tracking-wide">
          Status "Ag. Compra"
        </label>
        {statusQuery.isLoading ? (
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Loader2 className="h-4 w-4 animate-spin" />
            Carregando status…
          </div>
        ) : statusQuery.isError ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Erro ao carregar status de orçamento.
            </AlertDescription>
          </Alert>
        ) : (
          <Select value={localSituacao} onValueChange={setLocalSituacao}>
            <SelectTrigger className="text-sm">
              <SelectValue placeholder="Selecione o status…" />
            </SelectTrigger>
            <SelectContent>
              {statusQuery.data?.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.nome}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-md p-3 flex gap-2 text-xs text-blue-800">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <span>
          Selecione o status que representa <strong>"Aguardando Compra"</strong> no seu GestãoClick.
          O sistema varrerá todos os orçamentos nesse status e comparará o estoque de cada peça.
        </span>
      </div>

      {/* Scan button */}
      <Button
        className="w-full"
        onClick={handleVarrer}
        disabled={isScanning || !localSituacao}
      >
        {isScanning ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            Varrendo…
          </>
        ) : (
          <>
            <ScanLine className="h-4 w-4 mr-2" />
            Varrer Orçamentos
          </>
        )}
      </Button>

      {/* Progress */}
      {isScanning && (
        <div className="space-y-1.5">
          <Progress value={progressPct} className="h-2" />
          <p className="text-xs text-gray-500 truncate">{progress}</p>
        </div>
      )}

      {/* Legend */}
      <div className="space-y-1.5 pt-2 border-t">
        <p className="text-xs font-medium text-gray-600 uppercase tracking-wide">Legenda</p>
        <div className="flex flex-col gap-1.5 text-xs text-gray-600">
          <div className="flex items-center gap-2">
            <Badge className="bg-green-100 text-green-800 border-green-300 hover:bg-green-100 text-xs">✅ Pronto</Badge>
            <span>Todos os itens com estoque suficiente</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300 hover:bg-yellow-100 text-xs">⚠️ Parcial</Badge>
            <span>Alguns itens com estoque, outros não</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-red-100 text-red-800 border-red-300 hover:bg-red-100 text-xs">❌ Aguardando</Badge>
            <span>Nenhum item com estoque suficiente</span>
          </div>
        </div>
      </div>
    </div>
  );
}
