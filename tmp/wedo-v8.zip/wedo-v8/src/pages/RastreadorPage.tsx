import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getStatusOrcamentos } from '@/api/compras';
import { rastrearOrcamentos, RastreadorResult, OrcamentoReadiness, ConflictInfo } from '@/api/rastreador';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  Search, Loader2, CheckCircle2, AlertTriangle, ChevronDown, ChevronRight,
  PackageCheck, Clock, RefreshCw, Download, Printer, ShoppingCart, AlertCircle,
  X, ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';

function formatDateBR(d?: string) {
  if (!d) return '—';
  try { const [y, m, day] = d.split('-'); return `${day}/${m}/${y}`; } catch { return d; }
}

function exportCSV(result: RastreadorResult) {
  const header = [
    'Status', 'Código ORC', 'Cliente', 'Data', 'Convertido?',
    'Itens Prontos', 'Cobertos por PO', 'Total Itens',
    'Produto', 'Qtd Necessária', 'Estoque Disponível', 'Estoque Total',
    'Em Compra (PO)', 'Prazo PO', 'Pedido(s)',
    'Item Pronto', 'Coberto por PO',
  ];
  const rows: string[][] = [];

  const addRows = (entries: OrcamentoReadiness[], status: string) => {
    for (const e of entries) {
      for (const item of e.itens) {
        rows.push([
          status,
          e.orcamento.codigo,
          e.orcamento.nome_cliente,
          e.orcamento.data,
          e.convertido ? 'Sim' : 'Não',
          String(e.itensProntos),
          String(e.itensCobertospo),
          String(e.totalItens),
          item.nome_produto,
          String(item.qtd_necessaria),
          String(item.estoque_disponivel),
          String(item.estoque_total),
          String(item.qtd_em_compra),
          item.prazo_po ?? '',
          item.po_codigo ?? '',
          item.pronto ? 'Sim' : 'Não',
          item.coberto_po ? 'Sim' : 'Não',
        ]);
      }
    }
  };

  addRows(result.orcamentosProntos, 'Pronto para OS');
  addRows(result.orcamentosPendentes, 'Aguardando peças');

  const csv = [header, ...rows].map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `rastreador-orcamentos-${result.scannedAt.slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function RastreadorPage() {
  const [selectedSituacoes, setSelectedSituacoes] = useState<string[]>([]);
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState({ step: '', checked: 0, total: 0 });
  const [result, setResult] = useState<RastreadorResult | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [isPrintView, setIsPrintView] = useState(false);
  const [dismissedConvertidos, setDismissedConvertidos] = useState(false);

  const statusQuery = useQuery({
    queryKey: ['status-orcamentos'],
    queryFn: getStatusOrcamentos,
  });

  const toggleSituacao = (id: string) => {
    setSelectedSituacoes(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleScan = async () => {
    if (selectedSituacoes.length === 0) return;
    setScanning(true);
    setResult(null);
    setDismissedConvertidos(false);
    setProgress({ step: 'Iniciando…', checked: 0, total: 0 });
    try {
      const res = await rastrearOrcamentos(
        selectedSituacoes,
        (step, checked, total) => setProgress({ step, checked, total }),
      );
      setResult(res);
      const parts = [`${res.totalProntos} de ${res.totalOrcamentos} prontos`];
      if (res.totalConvertidos > 0) parts.push(`${res.totalConvertidos} já convertido(s)!`);
      toast.success(`Rastreamento concluído! ${parts.join(' · ')}`);
    } catch (err) {
      toast.error('Erro ao rastrear orçamentos');
      console.error(err);
    } finally {
      setScanning(false);
    }
  };

  const handlePrint = () => {
    setIsPrintView(true);
    setTimeout(() => {
      window.print();
      setIsPrintView(false);
    }, 300);
  };

  // ── OrcamentoCard ──────────────────────────────────────────────────────────
  const OrcamentoCard = ({ entry, ready }: { entry: OrcamentoReadiness; ready: boolean }) => {
    const expanded = expandedId === entry.orcamento.id;
    const hasPO = entry.itensCobertospo > 0;

    return (
      <Card
        className={`border-l-4 cursor-pointer transition-colors hover:bg-muted/50 ${
          ready
            ? 'border-l-green-500'
            : hasPO
            ? 'border-l-blue-500'
            : 'border-l-amber-500'
        } ${entry.convertido ? 'ring-1 ring-amber-400' : ''}`}
        onClick={() => setExpandedId(expanded ? null : entry.orcamento.id)}
      >
        {/* Converted warning banner */}
        {entry.convertido && (
          <div className="flex items-center gap-2 px-3 pt-2 pb-1 bg-amber-50 dark:bg-amber-950/30 rounded-t border-b border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300">
            <AlertCircle className="h-3.5 w-3.5 shrink-0" />
            <span className="text-[11px] font-medium">Orçamento já convertido em Venda/OS</span>
          </div>
        )}

        <div className="p-3">
          {/* Row 1: code + status badge + client + date */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {/* Código – first column, prominent */}
              <span className="font-bold text-sm shrink-0 tabular-nums">#{entry.orcamento.codigo}</span>
              <Badge
                className={`text-[10px] px-1.5 shrink-0 ${
                  ready
                    ? 'bg-green-600 text-white'
                    : hasPO
                    ? 'bg-blue-600 text-white'
                    : 'bg-amber-600 text-white'
                }`}
              >
                {entry.itensProntos}/{entry.totalItens}
                {hasPO ? ` +${entry.itensCobertospo}PO` : ''}
              </Badge>
              <span className="text-xs text-muted-foreground truncate">{entry.orcamento.nome_cliente}</span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs text-muted-foreground">{formatDateBR(entry.orcamento.data)}</span>
              {expanded ? <ChevronDown className="h-4 w-4 text-muted-foreground" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
            </div>
          </div>

          {/* Row 2: status icons */}
          <div className="flex items-center gap-3 mt-1">
            {ready
              ? <span className="flex items-center gap-1 text-[11px] text-green-600"><CheckCircle2 className="h-3 w-3" />Pronto para OS</span>
              : hasPO
              ? <span className="flex items-center gap-1 text-[11px] text-blue-600"><ShoppingCart className="h-3 w-3" />Parcialmente coberto por PO</span>
              : <span className="flex items-center gap-1 text-[11px] text-amber-600"><AlertTriangle className="h-3 w-3" />Aguardando peças</span>
            }
          </div>
        </div>

        {/* Expanded item table */}
        {expanded && (
          <div className="border-t border-border px-3 pb-3 pt-2">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-muted-foreground border-b border-border">
                  <th className="text-left py-1 pr-2 font-medium">Produto</th>
                  <th className="text-right py-1 px-1 font-medium">Precisa</th>
                  <th className="text-right py-1 px-1 font-medium">Estoque</th>
                  <th className="text-right py-1 px-1 font-medium">Em Compra</th>
                  <th className="text-left py-1 pl-1 font-medium">Prazo PO</th>
                  <th className="text-center py-1 pl-1 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {entry.itens.map((item, idx) => (
                  <tr key={idx} className="border-b border-border/40 hover:bg-muted/30">
                    <td className="py-1 pr-2 truncate max-w-[180px]">
                      <span title={item.nome_produto}>{item.nome_produto}</span>
                    </td>
                    <td className="text-right py-1 px-1 tabular-nums">{item.qtd_necessaria}</td>
                    <td className={`text-right py-1 px-1 tabular-nums font-medium ${
                      item.pronto ? 'text-green-600' : item.estoque_disponivel > 0 ? 'text-amber-600' : 'text-red-500'
                    }`}>
                      {item.estoque_disponivel}
                      {item.estoque_disponivel !== item.estoque_total && (
                        <span className="text-muted-foreground font-normal">/{item.estoque_total}</span>
                      )}
                    </td>
                    <td className={`text-right py-1 px-1 tabular-nums ${item.qtd_em_compra > 0 ? 'text-blue-600 font-medium' : 'text-muted-foreground'}`}>
                      {item.qtd_em_compra > 0 ? item.qtd_em_compra : '—'}
                    </td>
                    <td className="py-1 pl-1 text-muted-foreground">
                      {item.prazo_po ? (
                        <span title={`Pedido(s): ${item.po_codigo}`} className="text-blue-600 font-medium cursor-help">
                          {formatDateBR(item.prazo_po)}
                        </span>
                      ) : (
                        <span>—</span>
                      )}
                    </td>
                    <td className="text-center py-1 pl-1">
                      {item.pronto
                        ? <CheckCircle2 className="h-3.5 w-3.5 text-green-500 inline" />
                        : item.coberto_po
                        ? <ShoppingCart className="h-3.5 w-3.5 text-blue-500 inline" title="Coberto por pedido de compra" />
                        : <AlertTriangle className="h-3.5 w-3.5 text-red-500 inline" />
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    );
  };

  // ── Print view ─────────────────────────────────────────────────────────────
  if (isPrintView && result) {
    const renderSection = (title: string, entries: OrcamentoReadiness[]) =>
      entries.length > 0 && (
        <div className="mb-6">
          <h2 className="text-base font-bold mb-2 border-b pb-1">{title} ({entries.length})</h2>
          {entries.map(e => (
            <div key={e.orcamento.id} className="mb-4">
              <div className="flex justify-between items-baseline mb-1">
                <span className="font-semibold text-sm">
                  #{e.orcamento.codigo} — {e.orcamento.nome_cliente}
                  {e.convertido && ' ⚠️ CONVERTIDO'}
                </span>
                <span className="text-xs">
                  {formatDateBR(e.orcamento.data)} | {e.itensProntos}/{e.totalItens} prontos | {e.itensCobertospo} em PO
                </span>
              </div>
              <table className="w-full text-xs border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-0.5 pr-2">Produto</th>
                    <th className="text-right py-0.5 px-2">Precisa</th>
                    <th className="text-right py-0.5 px-2">Disponível</th>
                    <th className="text-right py-0.5 px-2">Em Compra</th>
                    <th className="text-center py-0.5 px-2">Prazo PO</th>
                    <th className="text-center py-0.5 pl-2">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {e.itens.map((item, idx) => (
                    <tr key={idx} className="border-b border-gray-200">
                      <td className="py-0.5 pr-2">{item.nome_produto}</td>
                      <td className="text-right py-0.5 px-2">{item.qtd_necessaria}</td>
                      <td className="text-right py-0.5 px-2">{item.estoque_disponivel}</td>
                      <td className="text-right py-0.5 px-2">{item.qtd_em_compra || '—'}</td>
                      <td className="text-center py-0.5 px-2">{formatDateBR(item.prazo_po)}</td>
                      <td className="text-center py-0.5 pl-2">
                        {item.pronto ? '✅' : item.coberto_po ? '🛒' : '❌'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      );

    return (
      <div className="p-6 bg-white text-black print-content">
        <h1 className="text-xl font-bold mb-1">Rastreador de Orçamentos</h1>
        <p className="text-xs text-gray-500 mb-4">
          Gerado em {new Date(result.scannedAt).toLocaleString('pt-BR')} |
          {result.totalProntos} prontos · {result.totalConvertidos} convertidos · {result.totalOrcamentos} analisados
        </p>
        {renderSection('✅ Prontos para virar OS', result.orcamentosProntos)}
        {result.conflitos.length > 0 && (
          <div className="mb-6">
            <h2 className="text-base font-bold mb-2 border-b pb-1">⚠️ Conflitos de Estoque ({result.conflitos.length})</h2>
            {result.conflitos.map(c => (
              <div key={c.produto_key} className="mb-2 text-xs">
                <span className="font-medium">{c.nome_produto}</span> — Estoque: {c.estoque_total}, Demanda: {c.demanda_total}
                <div className="ml-4">
                  {c.orcamentos_envolvidos.map(o => (
                    <div key={o.id}>#{o.codigo} — {o.nome_cliente} — precisa {o.qtd}</div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
        {renderSection('⏳ Aguardando peças', result.orcamentosPendentes)}
      </div>
    );
  }

  // ── Main render ────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)] bg-background no-print-content">

      {/* Top controls */}
      <div className="bg-card border-b border-border p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Search className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold text-foreground">Rastreador de Orçamentos</h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Selecione as situações para verificar quais orçamentos já possuem todas as peças em estoque e podem virar OS.
        </p>

        {statusQuery.isLoading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Carregando situações…
          </div>
        ) : (
          <div className="flex flex-wrap gap-3">
            {(statusQuery.data || []).map(s => (
              <label key={s.id} className="flex items-center gap-1.5 text-sm cursor-pointer">
                <Checkbox
                  checked={selectedSituacoes.includes(s.id)}
                  onCheckedChange={() => toggleSituacao(s.id)}
                  disabled={scanning}
                />
                {s.nome}
              </label>
            ))}
          </div>
        )}

        <div className="flex items-center gap-2 flex-wrap">
          <Button
            onClick={handleScan}
            disabled={selectedSituacoes.length === 0 || scanning}
            className="gap-2"
          >
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Rastrear Orçamentos
          </Button>
          {result && (
            <>
              <Button variant="outline" size="sm" onClick={handleScan} disabled={scanning} className="gap-1.5">
                <RefreshCw className="h-3.5 w-3.5" />
                Atualizar
              </Button>
              <Button variant="outline" size="sm" onClick={() => exportCSV(result)} className="gap-1.5">
                <Download className="h-3.5 w-3.5" />
                CSV
              </Button>
              <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1.5">
                <Printer className="h-3.5 w-3.5" />
                PDF
              </Button>
            </>
          )}
        </div>

        {scanning && (
          <div className="space-y-1">
            <Progress value={progress.total > 0 ? (progress.checked / progress.total) * 100 : 0} className="h-2" />
            <p className="text-xs text-muted-foreground text-center">
              {progress.step} {progress.total > 0 ? `${progress.checked}/${progress.total}` : ''}
            </p>
          </div>
        )}
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto p-4">
        {!result && !scanning && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
            <Search className="h-10 w-10 opacity-30" />
            <p className="text-sm">Selecione as situações e clique em "Rastrear" para verificar</p>
          </div>
        )}

        {result && (
          <div className="space-y-6 max-w-3xl mx-auto">

            {/* ── Converted budgets warning ── */}
            {result.orcamentosConvertidos.length > 0 && !dismissedConvertidos && (
              <div className="rounded-lg border border-amber-400 bg-amber-50 dark:bg-amber-950/30 p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-amber-800 dark:text-amber-300">
                        Atenção — {result.orcamentosConvertidos.length} orçamento(s) já convertido(s)
                      </p>
                      <p className="text-sm text-amber-700 dark:text-amber-400 mt-0.5">
                        Estes orçamentos já geraram Venda ou OS no GestãoClick. Verifique antes de qualquer ação.
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-amber-600 hover:text-amber-800 shrink-0"
                    onClick={e => { e.stopPropagation(); setDismissedConvertidos(true); }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {result.orcamentosConvertidos.map(c => (
                    <Badge key={c.orcamento_id} variant="outline" className="border-amber-400 text-amber-800 dark:text-amber-300 gap-1.5">
                      <span>#{c.codigo}</span>
                      <span className="text-amber-600">—</span>
                      <span>{c.nome_cliente}</span>
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-amber-400 text-amber-700 hover:bg-amber-100"
                    onClick={() => setDismissedConvertidos(true)}
                  >
                    Ignorar e continuar
                  </Button>
                  <Button
                    size="sm"
                    className="bg-amber-600 hover:bg-amber-700 text-white gap-1.5"
                    onClick={() => {
                      const url = 'https://app.gestaoclick.com.br/orcamentos';
                      window.open(url, '_blank');
                    }}
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                    Ver no GestãoClick
                  </Button>
                </div>
              </div>
            )}

            {/* Summary cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Card className="p-3 text-center">
                <p className="text-2xl font-bold text-foreground">{result.totalOrcamentos}</p>
                <p className="text-xs text-muted-foreground">Total analisados</p>
              </Card>
              <Card className="p-3 text-center border-green-500/50 bg-green-500/5">
                <p className="text-2xl font-bold text-green-600">{result.totalProntos}</p>
                <p className="text-xs text-muted-foreground">Prontos para OS</p>
              </Card>
              <Card className="p-3 text-center border-blue-500/50 bg-blue-500/5">
                <p className="text-2xl font-bold text-blue-600">
                  {result.orcamentosPendentes.filter(e => e.itensCobertospo > 0).length}
                </p>
                <p className="text-xs text-muted-foreground">Cobertos por PO</p>
              </Card>
              <Card className="p-3 text-center border-amber-500/50 bg-amber-500/5">
                <p className="text-2xl font-bold text-amber-600">
                  {result.totalOrcamentos - result.totalProntos}
                </p>
                <p className="text-xs text-muted-foreground">Aguardando peças</p>
              </Card>
            </div>

            {result.totalConvertidos > 0 && (
              <div className="flex items-center justify-between text-xs text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 rounded px-3 py-1.5 border border-amber-200">
                <span>⚠️ {result.totalConvertidos} orçamento(s) marcado(s) como já convertido(s)</span>
                {dismissedConvertidos && (
                  <button className="underline" onClick={() => setDismissedConvertidos(false)}>ver aviso</button>
                )}
              </div>
            )}

            <p className="text-xs text-muted-foreground text-right">
              Escaneado em {new Date(result.scannedAt).toLocaleString('pt-BR')}
            </p>

            {/* Legend */}
            <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> Pronto (estoque)</span>
              <span className="flex items-center gap-1"><ShoppingCart className="h-3.5 w-3.5 text-blue-500" /> Coberto por PO</span>
              <span className="flex items-center gap-1"><AlertTriangle className="h-3.5 w-3.5 text-red-500" /> Faltando</span>
              <span className="flex items-center gap-1"><AlertCircle className="h-3.5 w-3.5 text-amber-500" /> Convertido</span>
            </div>

            {/* Ready budgets */}
            {result.orcamentosProntos.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <PackageCheck className="h-4 w-4 text-green-600" />
                  <h2 className="text-sm font-bold text-foreground">
                    Prontos para virar OS ({result.orcamentosProntos.length})
                  </h2>
                </div>
                <div className="space-y-2">
                  {result.orcamentosProntos.map(entry => (
                    <OrcamentoCard key={entry.orcamento.id} entry={entry} ready />
                  ))}
                </div>
              </div>
            )}

            {/* Conflicts */}
            {result.conflitos.length > 0 && (
              <>
                <Separator />
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    <h2 className="text-sm font-bold text-foreground">
                      Conflitos de estoque ({result.conflitos.length})
                    </h2>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Peças disputadas por múltiplos orçamentos — o estoque não atende todos.
                  </p>
                  <div className="space-y-2">
                    {result.conflitos.map(c => (
                      <Card key={c.produto_key} className="p-3 border-l-4 border-l-red-500">
                        <p className="font-medium text-sm">{c.nome_produto}</p>
                        <div className="flex gap-3 text-xs text-muted-foreground mt-1">
                          <span>Estoque: <strong className="text-foreground">{c.estoque_total}</strong></span>
                          <span>Demanda total: <strong className="text-red-500">{c.demanda_total}</strong></span>
                        </div>
                        <div className="mt-2 space-y-0.5">
                          {c.orcamentos_envolvidos.map(o => (
                            <div key={o.id} className="text-xs text-muted-foreground">
                              #{o.codigo} — {o.nome_cliente} — precisa {o.qtd}
                            </div>
                          ))}
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              </>
            )}

            <Separator />

            {/* Pending budgets */}
            {result.orcamentosPendentes.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-amber-600" />
                  <h2 className="text-sm font-bold text-foreground">
                    Aguardando peças ({result.orcamentosPendentes.length})
                  </h2>
                </div>
                <div className="space-y-2">
                  {result.orcamentosPendentes.map(entry => (
                    <OrcamentoCard key={entry.orcamento.id} entry={entry} ready={false} />
                  ))}
                </div>
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
}
