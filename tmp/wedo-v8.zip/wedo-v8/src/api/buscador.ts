import { GCOrcamento, GCProdutoDetalhe, GCOrdemCompra } from './types';
import {
  apiRequest,
  isUsingMock,
  getProdutoDetalhe,
  listOrdensCompra,
  getStatusCompras,
} from './compras';

export interface BuscadorItem {
  produto_id: string;
  variacao_id: string;
  nome_produto: string;
  codigo_produto: string;
  qtd_necessaria: number;
  estoque_atual: number;
  qtd_em_compra: number;
  prazo_po?: string;
  po_codigo?: string;
  status: 'ok' | 'parcial' | 'falta';
}

export interface BuscadorDocumento {
  tipo: 'OS' | 'Orcamento';
  numero: string;
  cliente: string;
  data: string;
  situacao: string;
  items: BuscadorItem[];
  total_items: number;
  items_ok: number;
  items_parcial: number;
  items_falta: number;
  orcamento_id?: string;
  situacao_financeiro?: string;
  situacao_estoque?: string;
}

function normalizeId(v: string | number | null | undefined): string {
  if (v == null) return '';
  const s = String(v).trim();
  return (s === '0' || s.toLowerCase() === 'null') ? '' : s;
}

function parseDecimal(v: string | number | null | undefined): number {
  if (typeof v === 'number') return Number.isFinite(v) ? v : 0;
  if (v == null) return 0;
  const s = String(v).trim();
  if (!s) return 0;
  if (s.includes(',') && s.includes('.')) return parseFloat(s.replace(/\./g, '').replace(',', '.')) || 0;
  if (s.includes(',')) return parseFloat(s.replace(',', '.')) || 0;
  return parseFloat(s) || 0;
}

async function buildPOCoverageMap(): Promise<Map<string, { qtd: number; prazo?: string; codigos: string[] }>> {
  const map = new Map<string, { qtd: number; prazo?: string; codigos: string[] }>();
  try {
    const statuses = await getStatusCompras();
    for (const st of statuses) {
      const res = await listOrdensCompra(st.id);
      for (const po of res.data) {
        for (const p of po.produtos || []) {
          const pid = normalizeId(p.produto.produto_id);
          const vid = normalizeId(p.produto.variacao_id);
          if (!pid) continue;
          const key = vid ? `${pid}::${vid}` : pid;
          const qtd = parseDecimal(p.produto.quantidade);
          const existing = map.get(key);
          if (!existing) {
            map.set(key, { qtd, prazo: po.prazo_entrega || undefined, codigos: [po.codigo] });
          } else {
            existing.qtd += qtd;
            existing.codigos.push(po.codigo);
            if (po.prazo_entrega && (!existing.prazo || po.prazo_entrega < existing.prazo)) {
              existing.prazo = po.prazo_entrega;
            }
          }
        }
      }
    }
  } catch (e) {
    console.warn('[BUSCADOR] PO coverage failed:', e);
  }
  return map;
}

async function buildItems(
  produtos: Array<{ produto: { produto_id: string; variacao_id?: string; nome_produto?: string; codigo_produto?: string; quantidade: string | number } }>,
  detailCache: Map<string, GCProdutoDetalhe | null>,
  poCovMap: Map<string, { qtd: number; prazo?: string; codigos: string[] }>,
): Promise<BuscadorItem[]> {
  const items: BuscadorItem[] = [];
  for (const p of produtos) {
    const pid = normalizeId(p.produto.produto_id);
    const vid = normalizeId(p.produto.variacao_id);
    if (!pid) continue;

    let detail = detailCache.get(pid);
    if (detail === undefined) {
      detail = await getProdutoDetalhe(pid);
      detailCache.set(pid, detail);
    }

    let estoque = 0;
    if (detail) {
      if (vid && detail.variacoes?.length) {
        const v = detail.variacoes.find(v => String(v.variacao.id) === vid);
        estoque = v ? parseDecimal(v.variacao.estoque) : parseDecimal(detail.estoque);
      } else {
        estoque = parseDecimal(detail.estoque);
      }
    }

    const key = vid ? `${pid}::${vid}` : pid;
    const poCov = poCovMap.get(key);
    const qtdNec = parseDecimal(p.produto.quantidade);
    const qtdEmCompra = poCov?.qtd ?? 0;

    let status: BuscadorItem['status'];
    if (estoque >= qtdNec) {
      status = 'ok';
    } else if (estoque + qtdEmCompra >= qtdNec) {
      status = 'parcial';
    } else {
      status = 'falta';
    }

    items.push({
      produto_id: pid,
      variacao_id: vid,
      nome_produto: p.produto.nome_produto ?? '',
      codigo_produto: p.produto.codigo_produto ?? '',
      qtd_necessaria: qtdNec,
      estoque_atual: estoque,
      qtd_em_compra: qtdEmCompra,
      prazo_po: poCov?.prazo,
      po_codigo: poCov?.codigos.join(', '),
      status,
    });
  }
  return items;
}

export async function buscadorSearch(query: string): Promise<BuscadorDocumento[]> {
  const results: BuscadorDocumento[] = [];
  const detailCache = new Map<string, GCProdutoDetalhe | null>();
  const isNumeric = /^\d+$/.test(query.trim());

  // Build PO coverage map
  const poCovMap = await buildPOCoverageMap();

  if (isUsingMock()) {
    // Return mock data for demo
    return [
      {
        tipo: 'OS',
        numero: '1001',
        cliente: 'Restaurante Bom Sabor (DEMO)',
        data: new Date().toISOString().slice(0, 10),
        situacao: 'Em andamento',
        items: [],
        total_items: 0,
        items_ok: 0,
        items_parcial: 0,
        items_falta: 0,
      },
    ];
  }

  const seen = new Set<string>();

  // Search OS
  try {
    const osParam = isNumeric ? `codigo=${query}` : `nome=${encodeURIComponent(query)}`;
    const osRes = await apiRequest<{ data: any[] }>(`/api/ordens_servicos?${osParam}`);
    for (const row of osRes.data || []) {
      const os = row?.OrdemServico ?? row;
      const key = `OS-${os.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const produtos = (os.produtos || []).map((p: any) => ({
        produto: {
          produto_id: String(p?.produto?.produto_id ?? ''),
          variacao_id: String(p?.produto?.variacao_id ?? ''),
          nome_produto: String(p?.produto?.nome_produto ?? ''),
          codigo_produto: String(p?.produto?.codigo_produto ?? ''),
          quantidade: p?.produto?.quantidade ?? '1',
        },
      }));
      const items = await buildItems(produtos, detailCache, poCovMap);
      results.push({
        tipo: 'OS',
        numero: String(os.codigo ?? os.id),
        cliente: String(os.nome_cliente ?? ''),
        data: String(os.data ?? ''),
        situacao: String(os.nome_situacao ?? ''),
        items,
        total_items: items.length,
        items_ok: items.filter(i => i.status === 'ok').length,
        items_parcial: items.filter(i => i.status === 'parcial').length,
        items_falta: items.filter(i => i.status === 'falta').length,
      });
    }
  } catch (e) {
    console.warn('[BUSCADOR] OS search failed:', e);
  }

  // Search Orçamentos
  try {
    const orcParam = isNumeric ? `codigo=${query}` : `nome=${encodeURIComponent(query)}`;
    const orcRes = await apiRequest<{ data: any[] }>(`/api/orcamentos?${orcParam}`);
    for (const row of orcRes.data || []) {
      const orc = row?.Orcamento ?? row;
      const key = `ORC-${orc.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const produtos = (orc.produtos || []).map((p: any) => ({
        produto: {
          produto_id: String(p?.produto?.produto_id ?? ''),
          variacao_id: String(p?.produto?.variacao_id ?? ''),
          nome_produto: String(p?.produto?.nome_produto ?? ''),
          codigo_produto: String(p?.produto?.codigo_produto ?? ''),
          quantidade: p?.produto?.quantidade ?? '1',
        },
      }));
      const items = await buildItems(produtos, detailCache, poCovMap);
      results.push({
        tipo: 'Orcamento',
        numero: String(orc.codigo ?? orc.id),
        cliente: String(orc.nome_cliente ?? ''),
        data: String(orc.data ?? ''),
        situacao: String(orc.nome_situacao ?? orc.situacao ?? ''),
        items,
        total_items: items.length,
        items_ok: items.filter(i => i.status === 'ok').length,
        items_parcial: items.filter(i => i.status === 'parcial').length,
        items_falta: items.filter(i => i.status === 'falta').length,
        orcamento_id: String(orc.id ?? ''),
        situacao_financeiro: orc.situacao_financeiro ? String(orc.situacao_financeiro) : undefined,
        situacao_estoque: orc.situacao_estoque ? String(orc.situacao_estoque) : undefined,
      });
    }
  } catch (e) {
    console.warn('[BUSCADOR] ORC search failed:', e);
  }

  // Search by client name → OS + ORC
  if (!isNumeric) {
    try {
      const clientRes = await apiRequest<{ data: any[] }>(`/api/clientes?nome=${encodeURIComponent(query)}`);
      for (const row of clientRes.data || []) {
        const cliente = row?.Cliente ?? row;
        const clienteId = String(cliente.id ?? '');
        if (!clienteId) continue;

        // OS by cliente_id
        try {
          const osRes2 = await apiRequest<{ data: any[] }>(`/api/ordens_servicos?cliente_id=${clienteId}`);
          for (const row2 of osRes2.data || []) {
            const os = row2?.OrdemServico ?? row2;
            const key = `OS-${os.id}`;
            if (seen.has(key)) continue;
            seen.add(key);
            const produtos = (os.produtos || []).map((p: any) => ({
              produto: {
                produto_id: String(p?.produto?.produto_id ?? ''),
                variacao_id: String(p?.produto?.variacao_id ?? ''),
                nome_produto: String(p?.produto?.nome_produto ?? ''),
                codigo_produto: String(p?.produto?.codigo_produto ?? ''),
                quantidade: p?.produto?.quantidade ?? '1',
              },
            }));
            const items = await buildItems(produtos, detailCache, poCovMap);
            results.push({
              tipo: 'OS',
              numero: String(os.codigo ?? os.id),
              cliente: String(os.nome_cliente ?? ''),
              data: String(os.data ?? ''),
              situacao: String(os.nome_situacao ?? ''),
              items,
              total_items: items.length,
              items_ok: items.filter(i => i.status === 'ok').length,
              items_parcial: items.filter(i => i.status === 'parcial').length,
              items_falta: items.filter(i => i.status === 'falta').length,
            });
          }
        } catch {}

        // ORC by cliente_id
        try {
          const orcRes2 = await apiRequest<{ data: any[] }>(`/api/orcamentos?cliente_id=${clienteId}`);
          for (const row2 of orcRes2.data || []) {
            const orc = row2?.Orcamento ?? row2;
            const key = `ORC-${orc.id}`;
            if (seen.has(key)) continue;
            seen.add(key);
            const produtos = (orc.produtos || []).map((p: any) => ({
              produto: {
                produto_id: String(p?.produto?.produto_id ?? ''),
                variacao_id: String(p?.produto?.variacao_id ?? ''),
                nome_produto: String(p?.produto?.nome_produto ?? ''),
                codigo_produto: String(p?.produto?.codigo_produto ?? ''),
                quantidade: p?.produto?.quantidade ?? '1',
              },
            }));
            const items = await buildItems(produtos, detailCache, poCovMap);
            results.push({
              tipo: 'Orcamento',
              numero: String(orc.codigo ?? orc.id),
              cliente: String(orc.nome_cliente ?? ''),
              data: String(orc.data ?? ''),
              situacao: String(orc.nome_situacao ?? orc.situacao ?? ''),
              items,
              total_items: items.length,
              items_ok: items.filter(i => i.status === 'ok').length,
              items_parcial: items.filter(i => i.status === 'parcial').length,
              items_falta: items.filter(i => i.status === 'falta').length,
              orcamento_id: String(orc.id ?? ''),
              situacao_financeiro: orc.situacao_financeiro ? String(orc.situacao_financeiro) : undefined,
              situacao_estoque: orc.situacao_estoque ? String(orc.situacao_estoque) : undefined,
            });
          }
        } catch {}
      }
    } catch (e) {
      console.warn('[BUSCADOR] Client search failed:', e);
    }
  }

  return results;
}
