import { useState } from 'react';
import { buscadorSearch, BuscadorDocumento, BuscadorItem } from '@/api/buscador';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Search, Loader2, CheckCircle2, AlertTriangle, ShoppingCart,
  ChevronDown, ChevronRight, AlertCircle, X, ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';

function formatDateBR(d?: string) {
  if (!d) return '—';
  try { const [y, m, day] = d.split('-'); return `${day}/${m}/${y}`; } catch { return d; }
}

function StatusBadge({ status }: { status: BuscadorItem['status'] }) {
  if (status === 'ok') return <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />;
  if (status === 'parcial') return <ShoppingCart className="h-3.5 w-3.5 text-blue-500" />;
  return <AlertTriangle className="h-3.5 w-3.5 text-red-500" />;
}

function DocCard({ doc }: { doc: BuscadorDocumento }) {
  const [expanded, setExpanded] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const isConverted = doc.tipo === 'Orcamento' && doc.situacao_financeiro === '1' && doc.situacao_estoque === '1';

  const docColor = doc.items_falta > 0
    ? 'border-l-red-500'
    : doc.items_parcial > 0
    ? 'border-l-blue-500'
    : 'border-l-green-500';

  return (
    <Card className={`border-l-4 ${docColor} ${isConverted ? 'ring-1 ring-amber-400' : ''}`}>
      {/* Converted warning */}
      {isConverted && !dismissed && (
        <div className="flex items-start justify-between gap-2 px-3 pt-2 pb-1 bg-amber-50 dark:bg-amber-950/30 rounded-t border-b border-amber-200 dark:border-amber-800">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-3.5 w-3.5 text-amber-600 shrink-0" />
            <span className="text-[11px] font-medium text-amber-800 dark:text-amber-300">
              Orçamento já convertido em Venda/OS no GestãoClick
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {doc.orcamento_id && (
              <button
                className="text-[10px] text-amber-700 underline flex items-center gap-0.5"
                onClick={e => { e.stopPropagation(); window.open(`https://app.gestaoclick.com.br/orcamentos`, '_blank'); }}
              >
                <ExternalLink className="h-3 w-3" /> Ver no GC
              </button>
            )}
            <button onClick={e => { e.stopPropagation(); setDismissed(true); }}>
              <X className="h-3.5 w-3.5 text-amber-500 hover:text-amber-700 ml-1" />
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <div
        className="p-3 cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Badge
              className={`text-[10px] px-1.5 shrink-0 ${doc.tipo === 'OS' ? 'bg-primary text-primary-foreground' : 'bg-violet-600 text-white'}`}
            >
              {doc.tipo === 'OS' ? 'OS' : 'ORC'}
            </Badge>
            <span className="font-bold text-sm tabular-nums shrink-0">#{doc.numero}</span>
            <span className="text-xs text-muted-foreground truncate">{doc.cliente}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-xs text-muted-foreground">{formatDateBR(doc.data)}</span>
            {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </div>
        </div>

        <div className="flex items-center gap-3 mt-1.5">
          <span className="text-xs text-muted-foreground">{doc.situacao}</span>
          <span className="flex items-center gap-1 text-xs text-green-600">
            <CheckCircle2 className="h-3 w-3" />{doc.items_ok}
          </span>
          {doc.items_parcial > 0 && (
            <span className="flex items-center gap-1 text-xs text-blue-600">
              <ShoppingCart className="h-3 w-3" />{doc.items_parcial}
            </span>
          )}
          {doc.items_falta > 0 && (
            <span className="flex items-center gap-1 text-xs text-red-500">
              <AlertTriangle className="h-3 w-3" />{doc.items_falta}
            </span>
          )}
        </div>
      </div>

      {/* Expanded table */}
      {expanded && doc.items.length > 0 && (
        <div className="border-t border-border px-3 pb-3 pt-2">
          <table className="w-full text-xs">
            <thead>
              <tr className="text-muted-foreground border-b border-border">
                <th className="text-left py-1 pr-2 font-medium">Produto</th>
                <th className="text-right py-1 px-1 font-medium">Precisa</th>
                <th className="text-right py-1 px-1 font-medium">Estoque</th>
                <th className="text-right py-1 px-1 font-medium">Em Compra</th>
                <th className="text-left py-1 pl-1 font-medium">Prazo PO</th>
                <th className="text-center py-1 pl-1 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {doc.items.map((item, idx) => (
                <tr key={idx} className="border-b border-border/40 hover:bg-muted/30">
                  <td className="py-1 pr-2 max-w-[180px] truncate" title={item.nome_produto}>
                    {item.nome_produto}
                  </td>
                  <td className="text-right py-1 px-1 tabular-nums">{item.qtd_necessaria}</td>
                  <td className={`text-right py-1 px-1 tabular-nums font-medium ${
                    item.status === 'ok' ? 'text-green-600' : item.estoque_atual > 0 ? 'text-amber-600' : 'text-red-500'
                  }`}>
                    {item.estoque_atual}
                  </td>
                  <td className={`text-right py-1 px-1 tabular-nums ${item.qtd_em_compra > 0 ? 'text-blue-600 font-medium' : 'text-muted-foreground'}`}>
                    {item.qtd_em_compra > 0 ? item.qtd_em_compra : '—'}
                  </td>
                  <td className="py-1 pl-1 text-muted-foreground">
                    {item.prazo_po ? (
                      <span title={`Pedido(s): ${item.po_codigo}`} className="text-blue-600 font-medium cursor-help">
                        {formatDateBR(item.prazo_po)}
                      </span>
                    ) : '—'}
                  </td>
                  <td className="text-center py-1 pl-1">
                    <StatusBadge status={item.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {expanded && doc.items.length === 0 && (
        <div className="px-3 pb-3 text-xs text-muted-foreground">Nenhum produto listado.</div>
      )}
    </Card>
  );
}

export default function BuscadorPage() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<BuscadorDocumento[]>([]);
  const [searched, setSearched] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setSearched(true);
    try {
      const res = await buscadorSearch(query.trim());
      setResults(res);
      if (res.length === 0) toast.info('Nenhum documento encontrado para esta busca.');
      else toast.success(`${res.length} documento(s) encontrado(s).`);
    } catch (e) {
      toast.error('Erro na busca. Tente novamente.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-3.5rem)] bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Search className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold text-foreground">Buscador de Estoque</h1>
        </div>
        <p className="text-sm text-muted-foreground">
          Digite o nome do cliente, número da OS ou número do orçamento para verificar o estoque das peças necessárias.
        </p>
        <div className="flex gap-2">
          <Input
            placeholder="Ex: Restaurante Bom Sabor, 1042, 3005…"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            disabled={loading}
            className="flex-1"
          />
          <Button onClick={handleSearch} disabled={loading || !query.trim()} className="gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Buscar
          </Button>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><CheckCircle2 className="h-3.5 w-3.5 text-green-500" /> OK (estoque)</span>
          <span className="flex items-center gap-1"><ShoppingCart className="h-3.5 w-3.5 text-blue-500" /> Coberto por PO</span>
          <span className="flex items-center gap-1"><AlertTriangle className="h-3.5 w-3.5 text-red-500" /> Faltando</span>
          <span className="flex items-center gap-1"><AlertCircle className="h-3.5 w-3.5 text-amber-500" /> Convertido</span>
        </div>
      </div>

      {/* Results */}
      <div className="flex-1 overflow-y-auto p-4">
        {!searched && !loading && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
            <Search className="h-10 w-10 opacity-30" />
            <p className="text-sm">Digite um nome ou número acima para buscar</p>
          </div>
        )}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
            <Loader2 className="h-8 w-8 animate-spin" />
            <p className="text-sm">Consultando estoque…</p>
          </div>
        )}
        {!loading && searched && results.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground gap-2">
            <AlertTriangle className="h-10 w-10 opacity-30" />
            <p className="text-sm">Nenhum documento encontrado</p>
          </div>
        )}
        {!loading && results.length > 0 && (
          <div className="space-y-3 max-w-3xl mx-auto">
            {results.map((doc, idx) => (
              <DocCard key={idx} doc={doc} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
