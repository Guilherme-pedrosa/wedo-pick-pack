import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { TriagemResult } from '@/api/types';

interface TriagemConfig {
  situacaoAgCompraId: string;
}

interface TriagemStore {
  result: TriagemResult | null;
  isScanning: boolean;
  progress: string;
  progressPct: number;
  config: TriagemConfig;
  setResult: (r: TriagemResult | null) => void;
  setIsScanning: (v: boolean) => void;
  setProgress: (msg: string, pct?: number) => void;
  setConfig: (c: Partial<TriagemConfig>) => void;
}

export const useTriagemStore = create<TriagemStore>()(
  persist(
    (set) => ({
      result: null,
      isScanning: false,
      progress: '',
      progressPct: 0,
      config: {
        situacaoAgCompraId: '',
      },
      setResult: (result) => set({ result }),
      setIsScanning: (isScanning) => set({ isScanning }),
      setProgress: (progress, progressPct = 0) => set({ progress, progressPct }),
      setConfig: (c) =>
        set((s) => ({ config: { ...s.config, ...c } })),
    }),
    {
      name: 'wedo-triagem-store',
      partialize: (s) => ({ config: s.config }),
    }
  )
);
