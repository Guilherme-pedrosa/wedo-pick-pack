import { useState } from 'react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { ScanLine } from 'lucide-react';
import TriagemPanel from '@/components/triagem/TriagemPanel';
import TriagemResultPanel from '@/components/triagem/TriagemResultPanel';

export default function TriagemPage() {
  const [sheetOpen, setSheetOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-screen-xl mx-auto px-4 py-6">
        {/* Page header */}
        <div className="mb-6">
          <h1 className="text-xl font-bold text-gray-900">Triagem — Prontos para OS</h1>
          <p className="text-sm text-gray-500 mt-1">
            Varredura automática de orçamentos × estoque. Identifica quais podem virar OS agora.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Sidebar — desktop */}
          <aside className="hidden lg:block w-72 shrink-0">
            <div className="sticky top-20 bg-white rounded-xl border shadow-sm p-5">
              <TriagemPanel />
            </div>
          </aside>

          {/* Main content */}
          <main className="flex-1 min-w-0">
            <TriagemResultPanel />
          </main>
        </div>

        {/* Mobile trigger */}
        <div className="lg:hidden fixed bottom-4 left-1/2 -translate-x-1/2 z-40">
          <Sheet open={sheetOpen} onOpenChange={setSheetOpen}>
            <SheetTrigger asChild>
              <Button className="shadow-lg gap-2 px-6">
                <ScanLine className="h-4 w-4" />
                Varrer
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto rounded-t-xl">
              <div className="pt-2 pb-6">
                <TriagemPanel />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </div>
  );
}
