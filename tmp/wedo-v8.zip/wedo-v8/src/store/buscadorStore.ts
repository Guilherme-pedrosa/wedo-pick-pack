import { create } from 'zustand';
import { BuscadorDocumento } from '@/api/buscador';

interface BuscadorState {
  query: string;
  setQuery: (q: string) => void;
  loading: boolean;
  setLoading: (v: boolean) => void;
  results: BuscadorDocumento[];
  setResults: (r: BuscadorDocumento[]) => void;
  error: string | null;
  setError: (e: string | null) => void;
}

export const useBuscadorStore = create<BuscadorState>((set) => ({
  query: '',
  setQuery: (query) => set({ query }),
  loading: false,
  setLoading: (loading) => set({ loading }),
  results: [],
  setResults: (results) => set({ results }),
  error: null,
  setError: (error) => set({ error }),
}));
